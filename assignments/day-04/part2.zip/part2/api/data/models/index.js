require("./student.model");
//later we may require all models here without changing the db file
