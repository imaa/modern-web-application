const config = {
  models: {
    job: {
      name: "Job",
      collectionName: "jobs",
    },
    user: {
      name: "User",
      collectionName: "users",
    },
  },
};
module.exports.dbConfig = config;
