const models = {
  ProgramingLanguage: {
    name: "ProgramingLanguage",
    collection: "programingLanguages",
  },
  account: {
    name: "User",
    collection: "users",
  },
};
module.exports = { models };
