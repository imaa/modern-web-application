# Day 5 Assignments

This Repo contains the four parts of the assignment. you can run all parts together  
## Installation
 

```npm
// this will install all dependencies for all parts, run this on the root folder Day-05
npm run installAll
```

```npm
// run this on the root folder Day-05
npm start
```
## OR
```npm
// run this on the root folder Dya-05
 nodemon
```

## OR
```npm
// run this above commands on each part it will work also 
 nodemon
```

## Notes

Just to make it easy on you if you will run my apps, and I gain a little more experience while I configure this :)

 