const models = {
  ProgramingLanguage: {
    name: "ProgramingLanguage",
    collection: "programingLanguages",
  },
};
module.exports = { models };
